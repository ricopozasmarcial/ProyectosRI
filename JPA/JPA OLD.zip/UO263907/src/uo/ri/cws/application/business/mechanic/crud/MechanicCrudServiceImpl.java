package uo.ri.cws.application.business.mechanic.crud;

import java.util.List;
import java.util.Optional;

import uo.ri.cws.application.business.BusinessException;
import uo.ri.cws.application.business.mechanic.MechanicCrudService;
import uo.ri.cws.application.business.mechanic.MechanicDto;
import uo.ri.cws.application.business.mechanic.crud.commands.AddMechanic;
import uo.ri.cws.application.business.mechanic.crud.commands.DeleteMechanic;
import uo.ri.cws.application.business.mechanic.crud.commands.ListMechanic;
import uo.ri.cws.application.business.mechanic.crud.commands.UpdateMechanic;
import uo.ri.cws.application.business.util.command.CommandExecutor;

public class MechanicCrudServiceImpl implements MechanicCrudService {

	private CommandExecutor invoker;

	public MechanicCrudServiceImpl() {
		invoker = new CommandExecutor();
	}
	
	@Override
	public MechanicDto addMechanic(MechanicDto mecanico) throws BusinessException {
		return invoker.execute(new AddMechanic(mecanico));

	}

	@Override
	public void deleteMechanic(String idMecanico) throws BusinessException {
		invoker.execute(new DeleteMechanic(idMecanico));
	}

	@Override
	public void updateMechanic(MechanicDto mecanico) throws BusinessException {
		invoker.execute(new UpdateMechanic(mecanico));

	}

	@Override
	public Optional<MechanicDto> findMechanicById(String id) throws BusinessException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<MechanicDto> findAllMechanics() throws BusinessException {
		return invoker.execute(new ListMechanic());
	}


}
