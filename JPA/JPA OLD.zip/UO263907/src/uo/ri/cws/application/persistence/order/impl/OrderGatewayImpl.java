package uo.ri.cws.application.persistence.order.impl;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import alb.util.jdbc.Jdbc;
import uo.ri.cws.application.persistence.order.OrderGateway;
import uo.ri.cws.application.persistence.order.OrderRecord;
import uo.ri.cws.application.persistence.util.Conf;
import uo.ri.cws.application.persistence.util.RecordAssembler;

public class OrderGatewayImpl implements OrderGateway {

	@Override
	public void add(OrderRecord t) throws SQLException {
		// TODO Auto-generated method stub

	}

	@Override
	public void remove(String id) throws SQLException {
		// TODO Auto-generated method stub

	}

	@Override
	public void update(OrderRecord t) throws SQLException {
		// TODO Auto-generated method stub

	}

	@Override
	public Optional<OrderRecord> findById(String id) throws SQLException {
		return null;
	}

	@Override
	public List<OrderRecord> findAll() throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Optional<OrderRecord> findByCode(String code) throws SQLException {
		Connection c = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		OrderRecord order = new OrderRecord();
		try {
			c = Jdbc.getCurrentConnection();
			pst = c.prepareStatement(Conf.getInstance().getProperty("TORDERS_FIND_BY_CODE"));
			pst.setString(1, code);
			rs = pst.executeQuery();
			if(!rs.next())
				return Optional.empty();
			order = RecordAssembler.toOrderRecord(rs);
			return Optional.of(order);
		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			Jdbc.close(rs, pst);
		}
	}

	@Override
	public void updateDateAndStatus(LocalDate receptionDate, String status, String id) {
		Connection c = null;
		PreparedStatement pst = null;
		try {
			c = Jdbc.getCurrentConnection();
			pst = c.prepareStatement(Conf.getInstance().getProperty("TORDERS_UPDATE_DATE_AND_STATUS"));
			pst.setString(1, status);
			pst.setDate(2, Date.valueOf(receptionDate));
			pst.setString(3, id);
			pst.executeUpdate();
		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			Jdbc.close(pst);
		}

	}

	@Override
	public Optional<List<OrderRecord>> findByProviderNif(String nif) {
		Connection c = null;
		PreparedStatement pst = null;
		List<OrderRecord> result = new ArrayList<OrderRecord>();
		ResultSet rs = null;
		try {
			c = Jdbc.getCurrentConnection();
			pst = c.prepareStatement(Conf.getInstance().getProperty("TORDERS_FIND_BY_PROVIDER_NIF"));
			pst.setString(1, nif);
			rs = pst.executeQuery();
			if(!rs.isBeforeFirst())
				return Optional.empty();
			result = RecordAssembler.toOrderRecordList(rs);
			return Optional.of(result);
		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			Jdbc.close(rs, pst);
		}
	}

}
