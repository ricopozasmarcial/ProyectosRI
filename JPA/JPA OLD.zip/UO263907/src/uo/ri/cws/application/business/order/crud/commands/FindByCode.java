package uo.ri.cws.application.business.order.crud.commands;

import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

import uo.ri.cws.application.business.BusinessException;
import uo.ri.cws.application.business.order.OrderDto;
import uo.ri.cws.application.business.util.DtoMapper;
import uo.ri.cws.application.business.util.command.Command;
import uo.ri.cws.application.persistence.PersistenceFactory;
import uo.ri.cws.application.persistence.order.OrderGateway;
import uo.ri.cws.application.persistence.order.OrderRecord;
import uo.ri.cws.application.persistence.orderline.OrderLineGateway;
import uo.ri.cws.application.persistence.orderline.OrderLineRecord;
import uo.ri.cws.application.persistence.provider.ProviderGateway;
import uo.ri.cws.application.persistence.sparepart.SparePartGateway;

public class FindByCode implements Command<Optional<OrderDto>> {

	private String code;
	private OrderDto order;
	private OrderGateway og;
	private OrderLineGateway olg;
	private SparePartGateway sg;
	private ProviderGateway pg;

	public FindByCode(String code) {
		og = PersistenceFactory.forOrder();
		olg = PersistenceFactory.forOrderLine();
		sg = PersistenceFactory.forSparePart();
		pg = PersistenceFactory.forProvider();
		this.code = code;
		this.order = new OrderDto();
	}

	@Override
	public Optional<OrderDto> execute() throws BusinessException, SQLException {
		if(code.isEmpty() || code == null) {
			throw new IllegalArgumentException("The order code cannot be null or lenght 0");
		}
		Optional<OrderRecord> ord = og.findByCode(code);
		if (ord.isPresent()) {
			order = DtoMapper.toOrderDto(ord); // obtengo informacion base del pedido
			order.provider = DtoMapper.toOrderProviderDto(pg.findById(order.provider.id)); // obtengo informacion del
			Optional<List<OrderLineRecord>>	 orderlines = 	olg.findByOrderId(order.id);																		// proveedor del pedido
			if (orderlines.isPresent()) {
				order.lines = DtoMapper.toOrderLinesDto(orderlines); // obtengo informacion de las
																						// lineas del
				// pedido
				for (int i = 0; i < order.lines.size(); i++) { // obtengo informacion de cada una de las piezas en
																// especifico
					order.lines.get(i).sparePart = DtoMapper
							.toSparePartDto(sg.findById(order.lines.get(i).sparePart.id));
				}
				return Optional.of(order);
			}
			return Optional.of(order);
		}
		return Optional.empty();
	}

}
