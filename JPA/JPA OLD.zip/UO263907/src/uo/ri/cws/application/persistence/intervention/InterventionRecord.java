package uo.ri.cws.application.persistence.intervention;

import java.util.Date;

public class InterventionRecord {
	
	public String id;
	public Long version;

	public String workorderId;
	public String mechanicId;
	public Date date;
	public int minutes;
	
}
