/**
 * 
 */
package uo.ri.cws.application.business.order.crud;

import java.util.List;
import java.util.Optional;

import uo.ri.cws.application.business.BusinessException;
import uo.ri.cws.application.business.order.OrderDto;
import uo.ri.cws.application.business.order.OrdersService;
import uo.ri.cws.application.business.order.crud.commands.FindByCode;
import uo.ri.cws.application.business.order.crud.commands.FindByProviderNif;
import uo.ri.cws.application.business.order.crud.commands.ReceiveOrder;
import uo.ri.cws.application.business.util.command.CommandExecutor;

/**
 * @author Marcial Rico Pozas
 *
 */
public class OrderServiceImpl implements OrdersService {

	private CommandExecutor invoker;

	public OrderServiceImpl() {
		invoker = new CommandExecutor();
	}

	@Override
	public List<OrderDto> generateOrders() throws BusinessException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<OrderDto> findByProviderNif(String nif) throws BusinessException {
		return invoker.execute(new FindByProviderNif(nif));
	}

	@Override
	public Optional<OrderDto> findByCode(String code) throws BusinessException {
		return invoker.execute(new FindByCode(code));
	}

	@Override
	public OrderDto receive(String code) throws BusinessException {
		return invoker.execute(new ReceiveOrder(code));
	}

}
