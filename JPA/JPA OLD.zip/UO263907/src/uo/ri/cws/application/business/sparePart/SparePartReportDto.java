package uo.ri.cws.application.business.sparePart;

public class SparePartReportDto {
    public String id;
    public long version;

    public String code;
    public String description;
    public double price;
    public int stock;
    public int minStock;
    public int maxStock;
    public int totalUnitsSold;
}
