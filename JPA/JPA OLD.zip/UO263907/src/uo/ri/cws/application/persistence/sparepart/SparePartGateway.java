package uo.ri.cws.application.persistence.sparepart;

import java.util.Optional;

import uo.ri.cws.application.persistence.Gateway;

public interface SparePartGateway extends Gateway<SparePartRecord> {

	Optional<SparePartRecord> findByCode(String code);

}
