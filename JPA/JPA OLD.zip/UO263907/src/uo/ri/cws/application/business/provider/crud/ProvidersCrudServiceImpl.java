package uo.ri.cws.application.business.provider.crud;

import java.util.List;
import java.util.Optional;

import uo.ri.cws.application.business.BusinessException;
import uo.ri.cws.application.business.provider.ProviderDto;
import uo.ri.cws.application.business.provider.ProvidersCrudService;
import uo.ri.cws.application.business.provider.crud.commands.AddProvider;
import uo.ri.cws.application.business.provider.crud.commands.DeleteProvider;
import uo.ri.cws.application.business.provider.crud.commands.FindByName;
import uo.ri.cws.application.business.provider.crud.commands.FindByNif;
import uo.ri.cws.application.business.provider.crud.commands.FindBySparePartCode;
import uo.ri.cws.application.business.provider.crud.commands.UpdateProvider;
import uo.ri.cws.application.business.util.command.CommandExecutor;

public class ProvidersCrudServiceImpl implements ProvidersCrudService {

	private CommandExecutor invoker;
	
	public ProvidersCrudServiceImpl() {
		this.invoker = new CommandExecutor();
	}
	
	@Override
	public String add(ProviderDto dto) throws BusinessException {
		return invoker.execute(new AddProvider(dto));
	}

	@Override
	public void delete(String nif) throws BusinessException {
		invoker.execute(new DeleteProvider(nif));

	}

	@Override
	public void update(ProviderDto dto) throws BusinessException {
		invoker.execute(new UpdateProvider(dto));

	}

	@Override
	public Optional<ProviderDto> findByNif(String nif) throws BusinessException {
		return invoker.execute(new FindByNif(nif));
	}

	@Override
	public List<ProviderDto> findByName(String name) throws BusinessException {
		return invoker.execute(new FindByName(name));
	}

	@Override
	public List<ProviderDto> findBySparePartCode(String code) throws BusinessException {
		return invoker.execute(new FindBySparePartCode(code));
	}

}
