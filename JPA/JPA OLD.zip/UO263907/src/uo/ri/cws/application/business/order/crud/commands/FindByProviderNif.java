package uo.ri.cws.application.business.order.crud.commands;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import uo.ri.cws.application.business.BusinessException;
import uo.ri.cws.application.business.order.OrderDto;
import uo.ri.cws.application.business.util.DtoMapper;
import uo.ri.cws.application.business.util.command.Command;
import uo.ri.cws.application.persistence.PersistenceFactory;
import uo.ri.cws.application.persistence.order.OrderGateway;
import uo.ri.cws.application.persistence.order.OrderRecord;
import uo.ri.cws.application.persistence.orderline.OrderLineGateway;
import uo.ri.cws.application.persistence.provider.ProviderGateway;
import uo.ri.cws.application.persistence.sparepart.SparePartGateway;

public class FindByProviderNif implements Command<List<OrderDto>> {

	private String nif;
	private List<OrderDto> orders;
	private OrderGateway og;
	private OrderLineGateway olg;
	private ProviderGateway pg;
	private SparePartGateway sg;

	public FindByProviderNif(String nif) {
		this.nif = nif;
		this.og = PersistenceFactory.forOrder();
		this.olg = PersistenceFactory.forOrderLine();
		this.sg = PersistenceFactory.forSparePart();
		this.pg = PersistenceFactory.forProvider();
	}

	@Override
	public List<OrderDto> execute() throws BusinessException, SQLException {
		orders = new ArrayList<OrderDto>();
		if(nif.isEmpty() || nif == null) {
			throw new IllegalArgumentException("The provider NIF cannot be null or lenght 0");
		}
		Optional<List<OrderRecord>> opOrders = og.findByProviderNif(nif);
		if (opOrders.isPresent()) {
			orders = DtoMapper.toOrderListDto(opOrders); // obtengo informacion base del pedido
			for (int i = 0; i < orders.size(); i++) {
				orders.get(i).provider = DtoMapper.toOrderProviderDto(pg.findById(orders.get(i).provider.id)); // obtengo
																												// informacion
																												// del
				// proveedor del pedido
				orders.get(i).lines = DtoMapper.toOrderLinesDto(olg.findByOrderId(orders.get(i).id)); // obtengo
																										// informacion
																										// de las lineas
				// del
				// pedido
				for (int j = 0; j < orders.get(i).lines.size(); j++) { // obtengo informacion de cada una de las piezas
																		// en
					// especifico
					orders.get(i).lines.get(j).sparePart = DtoMapper
							.toSparePartDto(sg.findById(orders.get(i).lines.get(j).sparePart.id));
				}
			}

			return orders;
		}
		return orders;

	}

}
