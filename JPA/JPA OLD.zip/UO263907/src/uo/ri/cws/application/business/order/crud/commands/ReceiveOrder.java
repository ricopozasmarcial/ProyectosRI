package uo.ri.cws.application.business.order.crud.commands;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import uo.ri.cws.application.business.BusinessException;
import uo.ri.cws.application.business.order.OrderDto;
import uo.ri.cws.application.business.util.DtoMapper;
import uo.ri.cws.application.business.util.command.Command;
import uo.ri.cws.application.persistence.PersistenceFactory;
import uo.ri.cws.application.persistence.order.OrderGateway;
import uo.ri.cws.application.persistence.order.OrderRecord;
import uo.ri.cws.application.persistence.orderline.OrderLineGateway;
import uo.ri.cws.application.persistence.orderline.OrderLineRecord;
import uo.ri.cws.application.persistence.provider.ProviderGateway;
import uo.ri.cws.application.persistence.sparepart.SparePartGateway;
import uo.ri.cws.application.persistence.sparepart.SparePartRecord;

public class ReceiveOrder implements Command<OrderDto> {

	private OrderDto order;
	private OrderGateway og;
	private OrderLineGateway olg;
	private ProviderGateway pg;
	private SparePartGateway sg;
	private String code;

	public ReceiveOrder(String code) {
		og = PersistenceFactory.forOrder();
		olg = PersistenceFactory.forOrderLine();
		pg = PersistenceFactory.forProvider();
		sg = PersistenceFactory.forSparePart();
		this.code = code;
		this.order = new OrderDto();
	}

	public OrderDto execute() throws SQLException, BusinessException {
		if(code.isEmpty() || code == null) {
			throw new IllegalArgumentException("The order code cannot be null or lenght 0");
		}
		order = getOrder();
		// si no hay orderlines devuelvo el Dto
		if (!order.status.equals("PENDING")) {
			throw new BusinessException("This order has been received");
		}
		if (order.lines.size() != 0) {
			for (int i = 0; i < order.lines.size(); i++) {
				updatePriceAndQuantity(order.lines.get(i).price, order.lines.get(i).quantity,
						order.lines.get(i).sparePart.id);
			}
		}
		updateDateAndStatus();
		return order;
	}

	private OrderDto getOrder() throws SQLException, BusinessException {
		
		Optional<OrderRecord> orderR = og.findByCode(code); 
		if (!orderR.isPresent()) {
			throw new BusinessException("This order doesn't exist");
		}
		order = DtoMapper.toOrderDto(orderR); // obtengo informacion base del pedido
		order.provider = DtoMapper.toOrderProviderDto(pg.findById(order.provider.id)); // obtengo informacion del
																						// proveedor del pedido
		Optional<List<OrderLineRecord>> orderList = olg.findByOrderId(order.id);
		if (orderList.isPresent())
			order.lines = DtoMapper.toOrderLinesDto(orderList); // obtengo informacion de las lineas
																					// del
																					// pedido
		else 
			order.lines = new ArrayList<OrderDto.OrderLineDto>();
		
		for (int i = 0; i < order.lines.size(); i++) { // obtengo informacion de cada una de las piezas en especifico
			order.lines.get(i).sparePart = DtoMapper.toSparePartDto(sg.findById(order.lines.get(i).sparePart.id));
		}
		return order;
	}

	private void updateDateAndStatus() {
		order.receptionDate = LocalDate.now();
		order.status = "RECEIVED";
		og.updateDateAndStatus(order.receptionDate, order.status, order.id);
	}

	private void updatePriceAndQuantity(double price, int quantity, String id) throws SQLException, BusinessException {
		// obtengo valores actuales
		Optional<SparePartRecord> spare = sg.findById(id);
		double currentPrice = spare.get().price;
		int currentQuantity = spare.get().stock;
		int newquantity = quantity + currentQuantity;
		double newprice = (((currentQuantity * currentPrice) + ((price * quantity) * 1.2))
				/ (currentQuantity + quantity));
		if (newprice < 0 || newquantity < 0) {
			throw new IllegalArgumentException("There's an error with one of the parameters");
		}

		olg.updatePriceAndQuantity(newprice, newquantity, id);
	}
}