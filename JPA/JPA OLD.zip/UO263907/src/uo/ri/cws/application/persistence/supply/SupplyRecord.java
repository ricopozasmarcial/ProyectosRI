package uo.ri.cws.application.persistence.supply;

public class SupplyRecord {
	public String id;
	public long version;

	public String providerId;
	public String sparePartId;

	public double price;
	public int deliveryTerm;
}
