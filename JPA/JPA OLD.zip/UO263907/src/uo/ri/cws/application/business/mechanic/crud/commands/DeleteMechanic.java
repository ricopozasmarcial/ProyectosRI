package uo.ri.cws.application.business.mechanic.crud.commands;

import java.sql.SQLException;

import uo.ri.cws.application.business.BusinessException;
import uo.ri.cws.application.business.util.command.Command;
import uo.ri.cws.application.persistence.PersistenceFactory;
import uo.ri.cws.application.persistence.intervention.InterventionGateway;
import uo.ri.cws.application.persistence.mechanic.MechanicGateway;
import uo.ri.cws.application.persistence.workorder.WorkOrderGateway;

public class DeleteMechanic implements Command<Void> {

	private String mech;
	private MechanicGateway mg;
	private InterventionGateway ig;
	private WorkOrderGateway wg;

	public DeleteMechanic(String mechanic) {
		this.mech = mechanic;
		mg = PersistenceFactory.forMechanic();
		ig = PersistenceFactory.forIntervention();
		wg = PersistenceFactory.forWorkOrder();
	}

	public Void execute() throws SQLException, BusinessException {
		if(mech.isEmpty() || mech== null)
			throw new IllegalArgumentException("The String cannot be null or empty");
		if(!mechanicIdExists()) 
			throw new BusinessException("Mechanic id doesn't exists");
		if(!mechanicHasWordOrders()) 
			throw new BusinessException("Mechanic has work orders");
		if(!mechanicHasInterventions()) 
			throw new BusinessException("Mechanic has interventions");
		mg.remove(mech);
		return null;
	}
	
	private boolean mechanicIdExists() throws SQLException {
		if(mg.findById(mech)==null)
			return false;
		return true;
	}
	
	private boolean mechanicHasWordOrders() throws SQLException {
		return wg.findByMechanicId(mech).isEmpty(); //si esta vacia devolvemos true y por lo tanto no tiene workorders
	}
	
	private boolean mechanicHasInterventions() throws SQLException {
		return ig.findByMechanicId(mech).isEmpty(); //si esta vacia devolvemos true y por lo tanto no tiene interventions
	}

}
