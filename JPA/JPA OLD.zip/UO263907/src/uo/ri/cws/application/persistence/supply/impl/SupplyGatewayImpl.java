package uo.ri.cws.application.persistence.supply.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import alb.util.jdbc.Jdbc;
import uo.ri.cws.application.persistence.supply.SupplyGateway;
import uo.ri.cws.application.persistence.supply.SupplyRecord;
import uo.ri.cws.application.persistence.util.Conf;
import uo.ri.cws.application.persistence.util.RecordAssembler;

public class SupplyGatewayImpl implements SupplyGateway {

	@Override
	public void add(SupplyRecord t) throws SQLException {
		Connection c = null;
		PreparedStatement pst = null;
		try {
			c = Jdbc.getCurrentConnection();
			pst = c.prepareStatement(Conf.getInstance().getProperty("TSUPPLIES_ADD"));
			pst.setString(1, t.id);
			pst.setInt(2, t.deliveryTerm);
			pst.setDouble(3, t.price);
			pst.setString(4, t.providerId);
			pst.setString(5, t.sparePartId);
			pst.executeUpdate();

		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			Jdbc.close(pst);
		}

	}

	@Override
	public void remove(String id) throws SQLException {
		Connection c = null;
		PreparedStatement pst = null;

		try {
			c = Jdbc.getCurrentConnection();
			pst = c.prepareStatement(Conf.getInstance().getProperty("TSUPPLIES_REMOVE"));
			pst.setString(1, id);
			pst.executeUpdate();

		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			Jdbc.close(pst);
		}

	}

	@Override
	public void update(SupplyRecord t) throws SQLException {
		Connection c = null;
		PreparedStatement pst = null;
		try {
			c = Jdbc.getCurrentConnection();
			pst = c.prepareStatement(Conf.getInstance().getProperty("TSUPPLIES_UPDATE"));
			pst.setDouble(1, t.price);
			pst.setInt(2, t.deliveryTerm);
			pst.setString(3, t.id);
			pst.executeUpdate();

		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			Jdbc.close(pst);
		}

	}

	@Override
	public Optional<SupplyRecord> findById(String id) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<SupplyRecord> findAll() throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Optional<SupplyRecord> findByProviderNif(String nif) {
		Connection c = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		SupplyRecord supply = new SupplyRecord();
		try {
			c = Jdbc.getCurrentConnection();
			pst = c.prepareStatement(Conf.getInstance().getProperty("TSUPPLY_FIND_BY_PROVIDER_NIF"));
			pst.setString(1, nif);
			rs = pst.executeQuery();
			if (!rs.next())
				return null;
			supply = RecordAssembler.toSupplyRecord(rs);
			return Optional.of(supply);
		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			Jdbc.close(rs, pst);
		}
	}

	@Override
	public Optional<SupplyRecord> findByProviderNifAndCode(String code, String nif) {
		Connection c = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		SupplyRecord supply = new SupplyRecord();
		try {
			c = Jdbc.getCurrentConnection();
			pst = c.prepareStatement(Conf.getInstance().getProperty("TSUPPLY_FIND_BY_PROVIDER_NIF_AND_SPARE_CODE"));
			pst.setString(1, nif);
			pst.setString(2, code);
			rs = pst.executeQuery();
			if (!rs.next())
				return Optional.empty();
			supply = RecordAssembler.toSupplyRecord(rs);
			return Optional.of(supply);
		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			Jdbc.close(rs, pst);
		}

	}

	@Override
	public List<SupplyRecord> findAllByProviderNif(String nif) {
		Connection c = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		List<SupplyRecord> provider = new ArrayList<SupplyRecord>();
		try {
			c = Jdbc.getCurrentConnection();
			pst = c.prepareStatement(Conf.getInstance().getProperty("TSUPPLY_FIND_BY_PROVIDER_NIF"));
			pst.setString(1, nif);
			rs = pst.executeQuery();
			if (!rs.isBeforeFirst())
				return null;
			provider = RecordAssembler.toSupplyListRecord(rs);
			return provider;
		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			Jdbc.close(rs, pst);
		}
	}

	@Override
	public List<SupplyRecord> findAllBySparePart(String code) {
		Connection c = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		List<SupplyRecord> provider = new ArrayList<SupplyRecord>();
		try {
			c = Jdbc.getCurrentConnection();
			pst = c.prepareStatement(Conf.getInstance().getProperty("TSUPPLY_FIND_BY_SPARE_PART_CODE"));
			pst.setString(1, code);
			rs = pst.executeQuery();
			if (!rs.isBeforeFirst())
				return null;
			provider = RecordAssembler.toSupplyListRecord(rs);
			return provider;
		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			Jdbc.close(rs, pst);
		}
	}

}
