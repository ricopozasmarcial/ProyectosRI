package uo.ri.cws.application.business.provider.crud.commands;

import java.sql.SQLException;

import uo.ri.cws.application.business.BusinessException;
import uo.ri.cws.application.business.util.command.Command;
import uo.ri.cws.application.persistence.PersistenceFactory;
import uo.ri.cws.application.persistence.order.OrderGateway;
import uo.ri.cws.application.persistence.provider.ProviderGateway;
import uo.ri.cws.application.persistence.supply.SupplyGateway;

public class DeleteProvider implements Command<Void> {

	private String nif;
	private ProviderGateway pg;
	private SupplyGateway sg;
	private OrderGateway og;
	
	public DeleteProvider(String nif) {
		this.nif = nif;
		pg = PersistenceFactory.forProvider();
		sg = PersistenceFactory.forSupply();
		og = PersistenceFactory.forOrder();
	}
	
	@Override
	public Void execute() throws BusinessException, SQLException {
		if(nif.isEmpty() || nif == null) {
			throw new IllegalArgumentException("The provider NIF cannot be null or lenght 0");
		}
		if(!isProviderAlreadyAdded()) 
			throw new BusinessException("Provider doesn't exists");
		if(isProviderInOrder())
			throw new BusinessException("The provider is currently in some orders");
		if(isProviderSupplying())
			throw new BusinessException("The provider is supplying parts");
		pg.remove(nif);
		return null;
	}
	
	private boolean isProviderAlreadyAdded() throws SQLException {
		if (pg.findByNif(nif).isPresent())
			return true;
		return false;
	}
	
	private boolean isProviderSupplying() throws SQLException {
		if (sg.findByProviderNif(nif) == null)
			return false;
		return true;
	}
	
	private boolean isProviderInOrder() throws SQLException {
		if (!og.findByProviderNif(nif).isPresent())
			return false;
		return true;
	}
	

}
