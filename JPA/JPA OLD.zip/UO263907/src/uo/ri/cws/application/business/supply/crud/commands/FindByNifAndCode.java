package uo.ri.cws.application.business.supply.crud.commands;

import java.sql.SQLException;
import java.util.Optional;

import uo.ri.cws.application.business.BusinessException;
import uo.ri.cws.application.business.order.OrderDto.OrderedSpareDto;
import uo.ri.cws.application.business.provider.ProviderDto;
import uo.ri.cws.application.business.supply.SupplyDto;
import uo.ri.cws.application.business.util.DtoMapper;
import uo.ri.cws.application.business.util.command.Command;
import uo.ri.cws.application.persistence.PersistenceFactory;
import uo.ri.cws.application.persistence.provider.ProviderGateway;
import uo.ri.cws.application.persistence.sparepart.SparePartGateway;
import uo.ri.cws.application.persistence.supply.SupplyGateway;
import uo.ri.cws.application.persistence.supply.SupplyRecord;

public class FindByNifAndCode implements Command<Optional<SupplyDto>> {

	private String code;
	private String nif;
	private SupplyGateway sg;
	private ProviderGateway pg;
	private SparePartGateway spg;
	private SupplyDto supply;

	public FindByNifAndCode(String nif, String code) {
		this.nif = nif;
		this.code = code;
		sg = PersistenceFactory.forSupply();
		pg = PersistenceFactory.forProvider();
		spg = PersistenceFactory.forSparePart();
	}

	@Override
	public Optional<SupplyDto> execute() throws BusinessException, SQLException {
		if(nif.isEmpty() || nif == null || code.isEmpty() || code == null) {
			throw new IllegalArgumentException("The supply NIF or code cannot be null or lenght 0");
		}
		Optional<SupplyRecord> supplyR = sg.findByProviderNifAndCode(code, nif);
		if (supplyR.isPresent()) {
			supply = DtoMapper.toSupplyDto(supplyR).get();
			fecthSupply();
			return Optional.of(supply);
		}
		return Optional.empty();
	}

	private void fecthSupply() throws SQLException {
		ProviderDto provider = DtoMapper.toProviderDto(pg.findById(supply.provider.id)).get();
		supply.provider.nif = provider.nif;
		supply.provider.name = provider.name;
		OrderedSpareDto spare = DtoMapper.toSparePartDto(spg.findById(supply.sparePart.id));
		supply.sparePart.code = spare.code;
		supply.sparePart.description = spare.description;
	}

}
