package uo.ri.cws.application.persistence.mechanic;

public class MechanicRecord {

	public String id;
	public Long version;
	
	public String dni;
	public String name;
	public String surname;

}
