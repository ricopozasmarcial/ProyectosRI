package uo.ri.cws.application.persistence.provider;

public class ProviderRecord {
	public String id;
	public long version;

	public String nif;
	public String name;
	public String email;
	public String phone;
}
