package uo.ri.cws.application.business;

public class BusinessException extends Exception {
	private static final long serialVersionUID = -308694287126038961L;

	public BusinessException() {
	}

	public BusinessException(String message) {
		super(message);
	}

	public BusinessException(Throwable cause) {
		super(cause);
	}

	public BusinessException(String message, Throwable cause) {
		super(message, cause);
	}

}
