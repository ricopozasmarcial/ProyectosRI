package uo.ri.cws.application.business.mechanic.crud.commands;

import java.sql.SQLException;
import java.util.UUID;

import uo.ri.cws.application.business.BusinessException;
import uo.ri.cws.application.business.mechanic.MechanicDto;
import uo.ri.cws.application.business.util.DtoMapper;
import uo.ri.cws.application.business.util.command.Command;
import uo.ri.cws.application.persistence.PersistenceFactory;
import uo.ri.cws.application.persistence.mechanic.MechanicGateway;
import uo.ri.cws.application.persistence.mechanic.MechanicRecord;

public class AddMechanic implements Command<MechanicDto> {

	private MechanicDto mechanic;
	private MechanicGateway mg;

	public AddMechanic(MechanicDto mech) {
		this.mechanic = mech;
		mg = PersistenceFactory.forMechanic();
	}

	public MechanicDto execute() throws SQLException, BusinessException {
		//comprobar parametros
		if(!isDtoValid())
			throw new IllegalArgumentException("Some of the arguments appear to be not valid");
		if(isMechanicAlreadyAdded())
			throw new BusinessException("The mechanic is already added");
		mechanic.id = UUID.randomUUID().toString();
		MechanicRecord m = DtoMapper.toRecord(mechanic);
		mg.add(m);
		return mechanic;
	}
	
	private boolean isDtoValid() {
		if(this.mechanic.dni.isEmpty() || this.mechanic.name.isEmpty() || this.mechanic.surname.isEmpty())
			return false;
		if(this.mechanic.dni == null || this.mechanic.name== null || this.mechanic.surname== null)
			return false;
		return true;
	}
	
	private boolean isMechanicAlreadyAdded() throws SQLException {
		if(mg.findByDni(this.mechanic.dni)==null)
			return false;
		return true;
	}
}
