package uo.ri.cws.application.business.provider;

public class ProviderDto {
    public String id;
    public long version;

    public String nif;
    public String name;
    public String email;
    public String phone;
}
