package uo.ri.cws.application.business.provider.crud.commands;

import java.sql.SQLException;
import java.util.UUID;

import uo.ri.cws.application.business.BusinessException;
import uo.ri.cws.application.business.provider.ProviderDto;
import uo.ri.cws.application.business.util.DtoMapper;
import uo.ri.cws.application.business.util.command.Command;
import uo.ri.cws.application.persistence.PersistenceFactory;
import uo.ri.cws.application.persistence.provider.ProviderGateway;
import uo.ri.cws.application.persistence.provider.ProviderRecord;

public class AddProvider implements Command<String> {

	private ProviderDto provider;
	private ProviderGateway pg;

	public AddProvider(ProviderDto dto) {
		this.provider = dto;
		pg = PersistenceFactory.forProvider();
	}

	@Override
	public String execute() throws BusinessException, SQLException {
		// comprobar parametros
		if (!isDtoValid())
			throw new BusinessException("Some of the arguments appear to be not valid");
		if (isProviderAlreadyAdded())
			throw new BusinessException("The provider is already added");
		if (isMatchingAllButNif())
			throw new BusinessException("The provider cannot have name, email and phone matching with other providers");
		if (!emailHasArroba())
			throw new BusinessException("The provider's email must have an @");
		provider.id = UUID.randomUUID().toString();
		ProviderRecord m = DtoMapper.toProviderRecord(provider);
		pg.add(m);
		return provider.id;
	}

	private boolean isDtoValid() {
		if (this.provider.nif.isEmpty() || this.provider.name.isEmpty() || this.provider.email.isEmpty()
				|| this.provider.phone.isEmpty())
			return false;
		if (this.provider.nif == null || this.provider.name == null || this.provider.email == null
				|| this.provider.phone == null)
			return false;
		return true;
	}

	private boolean isMatchingAllButNif() {
		if (pg.findAllByNameEmailPhone(this.provider.name,this.provider.email,this.provider.phone) == null)
			return false;
		return true;
	}
	
	private boolean isProviderAlreadyAdded() throws SQLException {
		if (!pg.findByNif(this.provider.nif).isPresent())
			return false;
		return true;
	}

	private boolean emailHasArroba() {
		return provider.email.contains("@");
	}

}
