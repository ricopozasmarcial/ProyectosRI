package uo.ri.cws.application.business.provider.crud.commands;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import uo.ri.cws.application.business.BusinessException;
import uo.ri.cws.application.business.provider.ProviderDto;
import uo.ri.cws.application.business.util.DtoMapper;
import uo.ri.cws.application.business.util.command.Command;
import uo.ri.cws.application.persistence.PersistenceFactory;
import uo.ri.cws.application.persistence.provider.ProviderGateway;
import uo.ri.cws.application.persistence.provider.ProviderRecord;

public class FindBySparePartCode implements Command<List<ProviderDto>> {

	private String code;
	private ProviderGateway pg;
	
	public FindBySparePartCode(String code) {
		this.code = code;
		pg = PersistenceFactory.forProvider();
	}
	
	@Override
	public List<ProviderDto> execute() throws BusinessException, SQLException {
		if(code.isEmpty() || code == null) {
			throw new IllegalArgumentException("The spare part code cannot be null or lenght 0");
		}
		List<ProviderRecord> list = pg.findAllBySparePartCode(code);
		if (list != null)
			return DtoMapper.toProviderListDto(list);
		return new ArrayList<ProviderDto>();
	}

}
