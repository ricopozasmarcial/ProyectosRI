package uo.ri.cws.application.business.supply.crud.commands;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import uo.ri.cws.application.business.BusinessException;
import uo.ri.cws.application.business.order.OrderDto.OrderedSpareDto;
import uo.ri.cws.application.business.provider.ProviderDto;
import uo.ri.cws.application.business.supply.SupplyDto;
import uo.ri.cws.application.business.util.DtoMapper;
import uo.ri.cws.application.business.util.command.Command;
import uo.ri.cws.application.persistence.PersistenceFactory;
import uo.ri.cws.application.persistence.provider.ProviderGateway;
import uo.ri.cws.application.persistence.sparepart.SparePartGateway;
import uo.ri.cws.application.persistence.supply.SupplyGateway;
import uo.ri.cws.application.persistence.supply.SupplyRecord;

public class ListByProvider implements Command<List<SupplyDto>> {

	private String nif;
	private SupplyGateway sg;
	private ProviderGateway pg;
	private SparePartGateway spg;

	public ListByProvider(String nif) {
		this.nif = nif;
		sg = PersistenceFactory.forSupply();
		pg = PersistenceFactory.forProvider();
		spg = PersistenceFactory.forSparePart();
	}

	@Override
	public List<SupplyDto> execute() throws BusinessException, SQLException {
		if(nif.isEmpty() || nif == null) {
			throw new IllegalArgumentException("The supply NIF cannot be null or lenght 0");
		}
		List<SupplyRecord> listSupply = sg.findAllByProviderNif(nif);
		if (listSupply != null) {
			List<SupplyDto> supplies = DtoMapper.toSupplyListDto(listSupply);
			fecthSupplies(supplies);
			return supplies;
		}
		return new ArrayList<SupplyDto>();
		
	}

	private void fecthSupplies(List<SupplyDto> supplies) throws SQLException {
		for (SupplyDto supply : supplies) {
			ProviderDto provider = DtoMapper.toProviderDto(pg.findById(supply.provider.id)).get();
			supply.provider.nif = provider.nif;
			supply.provider.name = provider.name;
			OrderedSpareDto spare = DtoMapper.toSparePartDto(spg.findById(supply.sparePart.id));
			supply.sparePart.code = spare.code;
			supply.sparePart.description = spare.description;
		}
	}
}
