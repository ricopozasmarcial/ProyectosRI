package uo.ri.cws.application.business.supply.crud.commands;

import java.sql.SQLException;
import java.util.UUID;

import uo.ri.cws.application.business.BusinessException;
import uo.ri.cws.application.business.order.OrderDto.OrderedSpareDto;
import uo.ri.cws.application.business.provider.ProviderDto;
import uo.ri.cws.application.business.supply.SupplyDto;
import uo.ri.cws.application.business.util.DtoMapper;
import uo.ri.cws.application.business.util.command.Command;
import uo.ri.cws.application.persistence.PersistenceFactory;
import uo.ri.cws.application.persistence.provider.ProviderGateway;
import uo.ri.cws.application.persistence.sparepart.SparePartGateway;
import uo.ri.cws.application.persistence.supply.SupplyGateway;
import uo.ri.cws.application.persistence.supply.SupplyRecord;

public class AddSupply implements Command<String> {

	private SupplyDto supply;
	private SupplyGateway sg;
	private ProviderGateway pg;
	private SparePartGateway spg;

	public AddSupply(SupplyDto supply) {
		this.supply = supply;
		sg = PersistenceFactory.forSupply();
		pg = PersistenceFactory.forProvider();
		spg = PersistenceFactory.forSparePart();
	}

	@Override
	public String execute() throws BusinessException, SQLException {
		if (!isDtoValid())
			throw new BusinessException("Some of the arguments appear to be not valid");
		if (isSpareAlreadyAdded())
			throw new BusinessException("This spare is already being provided by this provider");
		checkProviderAndSpare();
		fecthSupply();
		supply.id = UUID.randomUUID().toString();
		SupplyRecord m = DtoMapper.toSupplyRecord(supply);
		sg.add(m);
		return supply.id;
	}

	private void fecthSupply() {
		ProviderDto provider = DtoMapper.toProviderDto(pg.findByNif(supply.provider.nif)).get();
		supply.provider.id = provider.id;
		supply.provider.name = provider.name;
		OrderedSpareDto spare = DtoMapper.toSparePartDto(spg.findByCode(supply.sparePart.code));
		supply.sparePart.id = spare.id;
		supply.sparePart.description = spare.description;
	}

	private boolean isDtoValid() {
		if (this.supply.provider.nif.isEmpty() || this.supply.sparePart.code.isEmpty() || this.supply.price < 0
				|| this.supply.deliveryTerm < 0)
			return false;
		if (this.supply.provider.nif == null || this.supply.sparePart.code == null)
			return false;
		return true;
	}

	private boolean isSpareAlreadyAdded() throws SQLException {
		if (!sg.findByProviderNifAndCode(supply.sparePart.code, supply.provider.nif).isPresent())
			return false;
		return true;
	}

	private void checkProviderAndSpare() throws BusinessException {
		if (!pg.findByNif(supply.provider.nif).isPresent())
			throw new BusinessException("The provider doesn't exist");
		if (!spg.findByCode(supply.sparePart.code).isPresent())
			throw new BusinessException("The spare part doesn't exist");
	}

}
