package uo.ri.cws.application.persistence.orderline;

import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

import uo.ri.cws.application.persistence.Gateway;

public interface OrderLineGateway extends Gateway<OrderLineRecord> {

	Optional<List<OrderLineRecord>> findByOrderId(String id) throws SQLException;

	void updatePriceAndQuantity(double price, int quantity, String id);

}
