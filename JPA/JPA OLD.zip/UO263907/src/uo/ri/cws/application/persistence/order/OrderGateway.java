package uo.ri.cws.application.persistence.order;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import uo.ri.cws.application.persistence.Gateway;

public interface OrderGateway extends Gateway<OrderRecord> {
	
	Optional<OrderRecord> findByCode(String code) throws SQLException;

	void updateDateAndStatus(LocalDate receptionDate, String status, String id);
	
	Optional<List<OrderRecord>> findByProviderNif(String nif);
}
