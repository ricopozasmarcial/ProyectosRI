package uo.ri.cws.application.ui.cashier.action;

import java.util.List;

import alb.util.console.Console;
import alb.util.menu.Action;
import uo.ri.cws.application.business.BusinessException;
import uo.ri.cws.application.business.BusinessFactory;
import uo.ri.cws.application.business.invoice.InvoicingWorkOrderDto;

public class UnchargedRepairsClientAction implements Action {

	/**
	 * Process:
	 * 
	 *   - Ask customer dni
	 *    
	 *   - Display all uncharged breakdowns  
	 *   		(status <> 'CHARGED'). For each breakdown, display 
	 *   		id, date, status, amount and description
	 */
	@Override
	public void execute() throws BusinessException {
		// Get info
		String dni = Console.readString("Dni"); 
		List<InvoicingWorkOrderDto> lista = BusinessFactory.forCreateInvoiceService().findWorkOrdersByClientDni(dni);
		//Printeamos el list que devuelve
		lista.clear();
	}

}
