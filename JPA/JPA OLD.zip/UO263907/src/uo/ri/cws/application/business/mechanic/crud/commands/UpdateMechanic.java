package uo.ri.cws.application.business.mechanic.crud.commands;

import java.sql.SQLException;

import uo.ri.cws.application.business.BusinessException;
import uo.ri.cws.application.business.mechanic.MechanicDto;
import uo.ri.cws.application.business.util.DtoMapper;
import uo.ri.cws.application.business.util.command.Command;
import uo.ri.cws.application.persistence.PersistenceFactory;
import uo.ri.cws.application.persistence.mechanic.MechanicGateway;
import uo.ri.cws.application.persistence.mechanic.MechanicRecord;

public class UpdateMechanic implements Command<Void> {

	private MechanicDto mechanic;
	private MechanicGateway mg;

	public UpdateMechanic(MechanicDto mechanic) {
		this.mechanic = mechanic;
		mg = PersistenceFactory.forMechanic();
	}

	public Void execute() throws SQLException, BusinessException {
		if(!isMechanicAlreadyAdded())
			throw new BusinessException("The mechanic doesn't exists");
		if(!isDtoValid())
			throw new IllegalArgumentException("Some of the arguments appear to be not valid");
		MechanicRecord m = DtoMapper.toRecord(mechanic);
		mg.update(m);
		return null;
	}
	
	private boolean isDtoValid() {
		if( this.mechanic.name.isEmpty() || this.mechanic.surname.isEmpty())
			return false;
		if(this.mechanic.name== null || this.mechanic.surname== null)
			return false;
		return true;
	}
	
	private boolean isMechanicAlreadyAdded() throws SQLException {
		if(mg.findById(this.mechanic.id)==null)
			return false;
		return true;
	}
}
