package uo.ri.cws.application.business.invoice;

import java.time.LocalDate;

public class InvoicingWorkOrderDto {

	public String id;
	public String description;
	public LocalDate date;
	public String status;
	public double total;
}
