package uo.ri.cws.application.business.invoice.create.commands;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.Instant;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.List;

import alb.util.jdbc.Jdbc;
import uo.ri.cws.application.business.invoice.InvoicingWorkOrderDto;
import uo.ri.cws.application.business.util.command.Command;

public class UnchargedRepairsClient implements Command<List<InvoicingWorkOrderDto>>{

	private static String SQL_CLIENTE_ID = "select * from TCLIENTS where TCLIENTS.DNI = ?";
	private static String SQL_COCHES_CLIENTE = "select * from TVEHICLES where TVEHICLES.CLIENT_ID = ?";
	private static String SQL_TRABAJOS = "select * from TWORKORDERS where TWORKORDERS.VEHICLE_ID = ? AND TWORKORDERS.STATUS='CHARGED'";
	private String dni;
	
	public UnchargedRepairsClient(String dni) {
		this.dni = dni;
	}
	
	public  List<InvoicingWorkOrderDto> execute(){
		Connection c = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		List<InvoicingWorkOrderDto> invoices = new ArrayList<InvoicingWorkOrderDto>();
		String id_coches = obtenerCocheCliente(obtenerClienteid());
		try {
			c = Jdbc.getConnection();
			pst = c.prepareStatement(SQL_TRABAJOS);
			pst.setString(1, id_coches);
			rs = pst.executeQuery();
			while(rs.next()) {
				InvoicingWorkOrderDto invoice = new InvoicingWorkOrderDto();
				invoice.id = rs.getString("ID");
				Date date = rs.getDate("DATE");
				ZoneId defaultZoneId = ZoneId.systemDefault();
				Instant instant = date.toInstant();
				invoice.date = instant.atZone(defaultZoneId).toLocalDate();
				invoice.total = rs.getDouble("AMOUNT");
				invoice.status = rs.getString("STATUS");
				invoice.description = rs.getString("DESCRIPTION");
				invoices.add(invoice);
			}
			return invoices;
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
		finally {
			Jdbc.close(rs, pst, c);
		}
	}
	
	private String obtenerClienteid(){
		Connection c = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		String id = "";
		try {
			c = Jdbc.getConnection();
			pst = c.prepareStatement(SQL_CLIENTE_ID);
			pst.setString(1, dni);
			rs = pst.executeQuery();
			while(rs.next()) {
				id= rs.getString("id");
			}
			return id;
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
		finally {
			Jdbc.close(rs, pst, c);
		}
	}
	
	private String obtenerCocheCliente(String id_client){
		Connection c = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		String id = "";
		try {
			c = Jdbc.getConnection();
			pst = c.prepareStatement(SQL_COCHES_CLIENTE);
			pst.setString(1, id_client);
			rs = pst.executeQuery();
			while(rs.next()) {
				id= rs.getString("id");
			}
			return id;
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
		finally {
			Jdbc.close(rs, pst, c);
		}
	}
	
}
