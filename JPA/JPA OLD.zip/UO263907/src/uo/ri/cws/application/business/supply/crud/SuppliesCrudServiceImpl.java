package uo.ri.cws.application.business.supply.crud;

import java.util.List;
import java.util.Optional;

import uo.ri.cws.application.business.BusinessException;
import uo.ri.cws.application.business.supply.SuppliesCrudService;
import uo.ri.cws.application.business.supply.SupplyDto;
import uo.ri.cws.application.business.supply.crud.commands.AddSupply;
import uo.ri.cws.application.business.supply.crud.commands.DeleteSupply;
import uo.ri.cws.application.business.supply.crud.commands.FindByNifAndCode;
import uo.ri.cws.application.business.supply.crud.commands.ListByProvider;
import uo.ri.cws.application.business.supply.crud.commands.ListBySparePart;
import uo.ri.cws.application.business.supply.crud.commands.UpdateSupply;
import uo.ri.cws.application.business.util.command.CommandExecutor;

public class SuppliesCrudServiceImpl implements SuppliesCrudService {

	private CommandExecutor invoker;

	public SuppliesCrudServiceImpl() {
		invoker = new CommandExecutor();
	}

	@Override
	public String add(SupplyDto dto) throws BusinessException {
		return invoker.execute(new AddSupply(dto));
	}

	@Override
	public void delete(String nif, String code) throws BusinessException {
		invoker.execute(new DeleteSupply(nif, code));
	}

	@Override
	public void update(SupplyDto dto) throws BusinessException {
		invoker.execute(new UpdateSupply(dto));

	}

	@Override
	public Optional<SupplyDto> findByNifAndCode(String nif, String code) throws BusinessException {
		return invoker.execute(new FindByNifAndCode(nif,code));
	}

	@Override
	public List<SupplyDto> findByProviderNif(String nif) throws BusinessException {
		return invoker.execute(new ListByProvider(nif));
	}

	@Override
	public List<SupplyDto> findBySparePartCode(String code) throws BusinessException {
		return invoker.execute(new ListBySparePart(code));
	}

}
