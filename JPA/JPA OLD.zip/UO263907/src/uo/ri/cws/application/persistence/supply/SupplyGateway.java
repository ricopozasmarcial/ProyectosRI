package uo.ri.cws.application.persistence.supply;

import java.util.List;
import java.util.Optional;

import uo.ri.cws.application.persistence.Gateway;

public interface SupplyGateway extends Gateway<SupplyRecord> {

	Optional<SupplyRecord> findByProviderNif(String nif);

	Optional<SupplyRecord> findByProviderNifAndCode(String code, String nif);

	List<SupplyRecord> findAllByProviderNif(String name);

	List<SupplyRecord> findAllBySparePart(String code);

}
