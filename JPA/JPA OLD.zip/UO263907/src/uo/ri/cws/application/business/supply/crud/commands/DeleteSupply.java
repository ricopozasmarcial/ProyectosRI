package uo.ri.cws.application.business.supply.crud.commands;

import java.sql.SQLException;

import uo.ri.cws.application.business.BusinessException;
import uo.ri.cws.application.business.util.command.Command;
import uo.ri.cws.application.persistence.PersistenceFactory;
import uo.ri.cws.application.persistence.supply.SupplyGateway;

public class DeleteSupply implements Command<Void> {

	private String nif;
	private String code;
	private SupplyGateway sg;
	
	public DeleteSupply(String nif, String code) {
		this.nif = nif;
		this.code = code;
		sg = PersistenceFactory.forSupply();
	}
	
	@Override
	public Void execute() throws BusinessException, SQLException {
		if(!supplyExists())
			throw new BusinessException("The supply doesn't exists");
		sg.remove(sg.findByProviderNifAndCode(code, nif).get().id);
		return null;
	}
	
	private boolean supplyExists() throws SQLException {
		if(!sg.findByProviderNifAndCode(code, nif).isPresent())
			return false;
		return true;
	}

}
