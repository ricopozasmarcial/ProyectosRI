package uo.ri.cws.application.business.invoice.create.commands;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;
import java.util.UUID;

import alb.util.math.Round;
import uo.ri.cws.application.business.BusinessException;
import uo.ri.cws.application.business.invoice.InvoiceDto;
import uo.ri.cws.application.business.util.DtoMapper;
import uo.ri.cws.application.business.util.command.Command;
import uo.ri.cws.application.persistence.PersistenceFactory;
import uo.ri.cws.application.persistence.invoice.InvoiceGateway;
import uo.ri.cws.application.persistence.workorder.WorkOrderGateway;

public class CreateInvoice implements Command<InvoiceDto> {

	private List<String> invoices;
	private WorkOrderGateway wg;
	private InvoiceGateway ig;

	public CreateInvoice(List<String> invoices) {
		this.invoices = invoices;
		wg = PersistenceFactory.forWorkOrder();
		ig = PersistenceFactory.forInvoice();
	}

	public InvoiceDto execute() throws BusinessException, SQLException {

		if (invoices == null || invoices.size() == 0)
			throw new IllegalArgumentException("The list of work orders must be at least size 1 and cannot be null");

		InvoiceDto invoice = new InvoiceDto();
		String result = wg.testRepairs(invoices);
		if (!result.isEmpty()) {
			throw new BusinessException("Workorder " + result);
		}

		long numberInvoice = ig.generateInvoiceNumber();
		LocalDate dateInvoice = LocalDate.now();
		double amount = wg.calculateTotalInvoice(invoices); // not vat included
		double vat = LocalDate.parse("2012-07-01").isBefore(dateInvoice) ? 21.0 : 18.0;
		double total = amount * (1 + vat / 100); // vat included
		total = Round.twoCents(total);
		invoice.number = numberInvoice;
		invoice.date = dateInvoice;
		invoice.total = total;
		invoice.vat = vat;
		invoice.status = "NOT_YET_PAID";
		invoice.id = UUID.randomUUID().toString();
		String idInvoice = ig.createInvoice(DtoMapper.toInvoiceRecord(invoice));
		wg.linkWorkorderInvoice(idInvoice, invoices);
		wg.updateWorkOrderStatus(invoices, "INVOICED");

		// compruebo que el dto ya existe
		return invoice;
	}
}
