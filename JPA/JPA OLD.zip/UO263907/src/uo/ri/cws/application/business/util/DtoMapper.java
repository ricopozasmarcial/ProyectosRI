package uo.ri.cws.application.business.util;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import uo.ri.cws.application.business.invoice.InvoiceDto;
import uo.ri.cws.application.business.mechanic.MechanicDto;
import uo.ri.cws.application.business.order.OrderDto;
import uo.ri.cws.application.business.order.OrderDto.OrderLineDto;
import uo.ri.cws.application.business.order.OrderDto.OrderedProviderDto;
import uo.ri.cws.application.business.order.OrderDto.OrderedSpareDto;
import uo.ri.cws.application.business.provider.ProviderDto;
import uo.ri.cws.application.business.supply.SupplyDto;
import uo.ri.cws.application.persistence.invoice.InvoiceRecord;
import uo.ri.cws.application.persistence.mechanic.MechanicRecord;
import uo.ri.cws.application.persistence.order.OrderRecord;
import uo.ri.cws.application.persistence.orderline.OrderLineRecord;
import uo.ri.cws.application.persistence.provider.ProviderRecord;
import uo.ri.cws.application.persistence.sparepart.SparePartRecord;
import uo.ri.cws.application.persistence.supply.SupplyRecord;

public class DtoMapper {

	public static MechanicDto toDto(String id, String dni, String name, String surname) {
		MechanicDto result = new MechanicDto();
		result.id = id;
		result.name = name;
		result.surname = surname;
		result.dni = dni;
		return result;
	}

	public static Optional<MechanicDto> toDto(Optional<MechanicRecord> arg) {
		Optional<MechanicDto> result = arg.isPresent() ? Optional.ofNullable(null)
				: Optional.ofNullable(toDto(arg.get().id, arg.get().dni, arg.get().name, arg.get().surname));
		return result;
	}

	public static List<MechanicDto> toDtoList(List<MechanicRecord> arg) {
		List<MechanicDto> result = new ArrayList<MechanicDto>();
		for (MechanicRecord mr : arg)
			result.add(toDto(mr.id, mr.dni, mr.name, mr.surname));
		return result;
	}

	public static MechanicRecord toRecord(MechanicDto arg) {
		MechanicRecord result = new MechanicRecord();
		result.id = arg.id;
		result.dni = arg.dni;
		result.name = arg.name;
		result.surname = arg.surname;
		return result;
	}

	public static InvoiceDto toDto(InvoiceRecord arg) {
		InvoiceDto result = new InvoiceDto();
		result.id = arg.id;
		result.number = arg.number;
		result.status = arg.status;
		result.date = arg.date;
		result.total = arg.total;
		result.vat = arg.vat;
		return result;
	}

	public static OrderDto toOrderDto(Optional<OrderRecord> arg) {
		OrderDto result = new OrderDto();
		result.id = arg.get().id;
		result.code = arg.get().code;
		result.amount = arg.get().amount;
		result.orderedDate = arg.get().orderedDate;
		result.receptionDate = arg.get().receptionDate;
		result.provider.id = arg.get().providerId;
		result.status = arg.get().status;
		return result;
	}

	public static OrderedProviderDto toOrderProviderDto(Optional<ProviderRecord> arg) {
		OrderedProviderDto result = new OrderedProviderDto();
		result.id = arg.get().id;
		result.name = arg.get().name;
		result.nif = arg.get().nif;
		return result;
	}

	public static List<OrderLineDto> toOrderLinesDto(Optional<List<OrderLineRecord>> arg) {
		List<OrderLineDto> result = new ArrayList<OrderLineDto>();
		for (int i = 0; i < arg.get().size(); i++) {
			OrderLineDto order = new OrderLineDto();
			order.price = arg.get().get(i).price;
			order.quantity = arg.get().get(i).quantity;
			order.sparePart.id = arg.get().get(i).sparePart_id;
			result.add(order);
		}
		return result;
	}

	public static OrderedSpareDto toSparePartDto(Optional<SparePartRecord> arg) {
		OrderedSpareDto result = new OrderedSpareDto();
		result.id = arg.get().id;
		result.code = arg.get().code;
		result.description = arg.get().description;
		return result;
	}

	public static List<OrderDto> toOrderListDto(Optional<List<OrderRecord>> arg) {
		List<OrderDto> result = new ArrayList<OrderDto>();
		for (int i = 0; i < arg.get().size(); i++) {
			OrderDto order = new OrderDto();
			order.id = arg.get().get(i).id;
			order.amount = arg.get().get(i).amount;
			order.code = arg.get().get(i).code;
			order.orderedDate = arg.get().get(i).orderedDate;
			order.receptionDate = arg.get().get(i).receptionDate;
			order.status = arg.get().get(i).status;
			order.provider.id = arg.get().get(i).providerId;
			result.add(order);
		}
		return result;
	}

	public static ProviderRecord toProviderRecord(ProviderDto arg) {
		ProviderRecord result = new ProviderRecord();
		result.id = arg.id;
		result.email = arg.email;
		result.nif = arg.nif;
		result.name = arg.name;
		result.phone = arg.phone;
		return result;
	}

	public static Optional<ProviderDto> toProviderDto(Optional<ProviderRecord> arg) {
		Optional<ProviderDto> result = Optional.of(new ProviderDto());
		result.get().id = arg.get().id;
		result.get().name = arg.get().name;
		result.get().email = arg.get().email;
		result.get().nif = arg.get().nif;
		result.get().phone = arg.get().phone;
		return result;
	}

	public static List<ProviderDto> toProviderListDto(List<ProviderRecord> arg) {
		List<ProviderDto> result = new ArrayList<ProviderDto>();
		for (ProviderRecord mr : arg)
			result.add(toProviderDto(Optional.of(mr)).get());
		return result;
	}

	public static SupplyRecord toSupplyRecord(SupplyDto arg) {
		SupplyRecord result = new SupplyRecord();
		result.id = arg.id;
		result.deliveryTerm = arg.deliveryTerm;
		result.price = arg.price;
		result.providerId = arg.provider.id;
		result.sparePartId = arg.sparePart.id;
		return result;
	}

	public static Optional<SupplyDto> toSupplyDto(Optional<SupplyRecord> arg) {
		Optional<SupplyDto> result = Optional.of(new SupplyDto());
		result.get().id = arg.get().id;
		result.get().deliveryTerm = arg.get().deliveryTerm;
		result.get().price = arg.get().price;
		result.get().provider.id = arg.get().providerId;
		result.get().sparePart.id = arg.get().sparePartId;
		return result;
	}

	public static List<SupplyDto> toSupplyListDto(List<SupplyRecord> arg) {
		List<SupplyDto> result = new ArrayList<SupplyDto>();
		for (SupplyRecord mr : arg)
			result.add(toSupplyDto(Optional.of(mr)).get());
		return result;
	}

	public static InvoiceRecord toInvoiceRecord(InvoiceDto arg) {
		InvoiceRecord result = new InvoiceRecord();
		result.id = arg.id;
		result.date = arg.date;
		result.number = arg.number;
		result.status = arg.status;
		result.total = arg.total;
		result.vat = arg.vat;
		return result;
	}

}
