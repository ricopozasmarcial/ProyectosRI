package uo.ri.cws.application.persistence.provider;

import java.util.List;
import java.util.Optional;

import uo.ri.cws.application.persistence.Gateway;

public interface ProviderGateway extends Gateway<ProviderRecord>{

	Optional<ProviderRecord> findByNif(String nif);

	List<ProviderRecord> findAllByNameEmailPhone(String name, String email, String phone);

	List<ProviderRecord> findAllByName(String name);

	List<ProviderRecord> findAllBySparePartCode(String code);

}
