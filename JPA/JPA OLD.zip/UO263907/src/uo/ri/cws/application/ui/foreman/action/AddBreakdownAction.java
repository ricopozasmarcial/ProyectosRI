package uo.ri.cws.application.ui.foreman.action;

import alb.util.menu.Action;
import uo.ri.cws.application.business.BusinessException;

public class AddBreakdownAction implements Action {

	@Override
	public void execute() throws BusinessException {
		// TODO Auto-generated method stub
		
	}

}
