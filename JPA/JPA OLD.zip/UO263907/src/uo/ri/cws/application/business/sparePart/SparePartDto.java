package uo.ri.cws.application.business.sparePart;

public class SparePartDto {
    public String id;
    public long version;

    public String code;
    public String description;
    public int stock;
    public int minStock;
    public int maxStock;
    public double price;
}
