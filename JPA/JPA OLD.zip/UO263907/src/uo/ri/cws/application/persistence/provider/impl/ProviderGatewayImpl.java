package uo.ri.cws.application.persistence.provider.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import alb.util.jdbc.Jdbc;
import uo.ri.cws.application.persistence.provider.ProviderGateway;
import uo.ri.cws.application.persistence.provider.ProviderRecord;
import uo.ri.cws.application.persistence.util.Conf;
import uo.ri.cws.application.persistence.util.RecordAssembler;

public class ProviderGatewayImpl implements ProviderGateway {

	@Override
	public void add(ProviderRecord t) throws SQLException {
		Connection c = null;
		PreparedStatement pst = null;
		try {
			c = Jdbc.getCurrentConnection();
			pst = c.prepareStatement(Conf.getInstance().getProperty("TPROVIDERS_ADD"));
			pst.setString(1, t.id);
			pst.setString(2, t.email);
			pst.setString(3, t.name);
			pst.setString(4, t.nif);
			pst.setString(5, t.phone);
			pst.executeUpdate();

		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			Jdbc.close(pst);
		}

	}

	@Override
	public void remove(String id) throws SQLException {
		Connection c = null;
		PreparedStatement pst = null;

		try {
			c = Jdbc.getCurrentConnection();
			pst = c.prepareStatement(Conf.getInstance().getProperty("TPROVIDERS_REMOVE"));
			pst.setString(1, id);
			pst.executeUpdate();

		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			Jdbc.close(pst);
		}

	}

	@Override
	public void update(ProviderRecord t) throws SQLException {
		Connection c = null;
		PreparedStatement pst = null;
		try {
			c = Jdbc.getCurrentConnection();
			pst = c.prepareStatement(Conf.getInstance().getProperty("TPROVIDERS_UPDATE"));
			pst.setString(1, t.name);
			pst.setString(2, t.email);
			pst.setString(3, t.phone);
			pst.setString(4, t.id);
			pst.executeUpdate();

		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			Jdbc.close(pst);
		}

	}

	@Override
	public Optional<ProviderRecord> findById(String id) throws SQLException {
		Connection c = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		ProviderRecord provider = new ProviderRecord();
		try {
			c = Jdbc.getCurrentConnection();
			pst = c.prepareStatement(Conf.getInstance().getProperty("TPROVIDERS_FIND_BY_ID"));
			pst.setString(1, id);
			rs = pst.executeQuery();
			if(!rs.next())
				return null;
			provider = RecordAssembler.toProviderRecord(rs);
			return Optional.of(provider);
		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			Jdbc.close(rs, pst);
		}
	}

	@Override
	public List<ProviderRecord> findAll() throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Optional<ProviderRecord> findByNif(String nif) {
		Connection c = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		ProviderRecord provider = new ProviderRecord();
		try {
			c = Jdbc.getCurrentConnection();
			pst = c.prepareStatement(Conf.getInstance().getProperty("TPROVIDERS_FIND_BY_NIF"));
			pst.setString(1, nif);
			rs = pst.executeQuery();
			if(!rs.next())
				return Optional.empty();
			provider = RecordAssembler.toProviderRecord(rs);
			return Optional.of(provider);
		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			Jdbc.close(rs, pst);
		}
	}

	@Override
	public List<ProviderRecord> findAllByNameEmailPhone(String name, String email, String phone) {
		Connection c = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		List<ProviderRecord> provider = new ArrayList<ProviderRecord>();
		try {
			c = Jdbc.getCurrentConnection();
			pst = c.prepareStatement(Conf.getInstance().getProperty("TPROVIDERS_FIND_ALL_BY_NAME_EMAIL_PHONE"));
			pst.setString(1, name.toLowerCase());
			pst.setString(2, email.toLowerCase());
			pst.setString(3, phone.toLowerCase());
			rs = pst.executeQuery();
			if (!rs.isBeforeFirst())
				return null;
			provider = RecordAssembler.toProviderListRecord(rs);
			return provider;
		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			Jdbc.close(rs, pst);
		}
	}

	@Override
	public List<ProviderRecord> findAllByName(String name) {
		Connection c = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		List<ProviderRecord> provider = new ArrayList<ProviderRecord>();
		try {
			c = Jdbc.getCurrentConnection();
			pst = c.prepareStatement(Conf.getInstance().getProperty("TPROVIDERS_FIND_ALL_BY_NAME"));
			pst.setString(1, "%" + name.toLowerCase() + "%");
			rs = pst.executeQuery();

			if (!rs.isBeforeFirst())
				return null;
			provider = RecordAssembler.toProviderListRecord(rs);
			return provider;
		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			Jdbc.close(rs, pst);
		}
	}

	@Override
	public List<ProviderRecord> findAllBySparePartCode(String code) {
		Connection c = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		List<ProviderRecord> provider = new ArrayList<ProviderRecord>();
		try {
			c = Jdbc.getCurrentConnection();
			pst = c.prepareStatement(Conf.getInstance().getProperty("TPROVIDERS_FIND_ALL_BY_SPARE_PART_CODE"));
			pst.setString(1, code);
			rs = pst.executeQuery();

			if (!rs.isBeforeFirst())
				return null;
			provider = RecordAssembler.toProviderListRecord(rs);
			return provider;
		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			Jdbc.close(rs, pst);
		}
	}

}
