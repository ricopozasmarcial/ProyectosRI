package uo.ri.cws.application.business.supply.crud.commands;

import java.sql.SQLException;

import uo.ri.cws.application.business.BusinessException;
import uo.ri.cws.application.business.supply.SupplyDto;
import uo.ri.cws.application.business.util.DtoMapper;
import uo.ri.cws.application.business.util.command.Command;
import uo.ri.cws.application.persistence.PersistenceFactory;
import uo.ri.cws.application.persistence.supply.SupplyGateway;
import uo.ri.cws.application.persistence.supply.SupplyRecord;

public class UpdateSupply implements Command<Void> {

	private SupplyDto supply;
	private SupplyGateway sg;

	public UpdateSupply(SupplyDto supply) {
		this.supply = supply;
		sg = PersistenceFactory.forSupply();
	}

	@Override
	public Void execute() throws BusinessException, SQLException {
		if (!isSpareAlreadyAdded())
			throw new BusinessException("The supply doesn't exists");
		if (!isDtoValid())
			throw new BusinessException("Some of the arguments appear to be not valid");
		SupplyRecord m = DtoMapper.toSupplyRecord(supply);
		sg.update(m);
		return null;
	}

	private boolean isDtoValid() {
		if (this.supply.provider.nif.isEmpty() || this.supply.sparePart.code.isEmpty() || this.supply.price < 0
				|| this.supply.deliveryTerm < 0)
			return false;
		if (this.supply.provider.nif == null || this.supply.sparePart.code == null)
			return false;
		return true;
	}

	private boolean isSpareAlreadyAdded() throws SQLException {
		if (!sg.findByProviderNifAndCode(supply.sparePart.code, supply.provider.nif).isPresent())
			return false;
		return true;
	}

}
