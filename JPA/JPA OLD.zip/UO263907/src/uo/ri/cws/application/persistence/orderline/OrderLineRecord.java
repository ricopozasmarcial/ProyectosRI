package uo.ri.cws.application.persistence.orderline;

public class OrderLineRecord {
	
	public double price;
	public int quantity;
	public String sparePart_id;
	public String order_id;
	
}
