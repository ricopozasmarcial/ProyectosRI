package uo.ri.cws.application.persistence.sparepart.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

import alb.util.jdbc.Jdbc;
import uo.ri.cws.application.persistence.sparepart.SparePartGateway;
import uo.ri.cws.application.persistence.sparepart.SparePartRecord;
import uo.ri.cws.application.persistence.util.Conf;
import uo.ri.cws.application.persistence.util.RecordAssembler;

public class SparePartGatewayImpl implements SparePartGateway {

	@Override
	public void add(SparePartRecord t) throws SQLException {
		// TODO Auto-generated method stub

	}

	@Override
	public void remove(String id) throws SQLException {
		// TODO Auto-generated method stub

	}

	@Override
	public void update(SparePartRecord t) throws SQLException {
		// TODO Auto-generated method stub

	}

	@Override
	public Optional<SparePartRecord> findById(String id) throws SQLException {
		Connection c = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		SparePartRecord sparePart = new SparePartRecord();
		try {
			c = Jdbc.getCurrentConnection();
			pst = c.prepareStatement(Conf.getInstance().getProperty("TSPAREPARTS_FIND_BY_ID"));
			pst.setString(1, id);
			rs = pst.executeQuery();
			if(!rs.next())
				return null;
			sparePart = RecordAssembler.toSparePartRecord(rs);
			return Optional.of(sparePart);
		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			Jdbc.close(rs, pst);
		}
	}

	@Override
	public List<SparePartRecord> findAll() throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Optional<SparePartRecord> findByCode(String code) {
		Connection c = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		SparePartRecord sparePart = new SparePartRecord();
		try {
			c = Jdbc.getCurrentConnection();
			pst = c.prepareStatement(Conf.getInstance().getProperty("TSPAREPARTS_FIND_BY_CODE"));
			pst.setString(1, code);
			rs = pst.executeQuery();
			if(!rs.next())
				return Optional.empty();
			sparePart = RecordAssembler.toSparePartRecord(rs);
			return Optional.of(sparePart);
		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			Jdbc.close(rs, pst);
		}
	}

}
