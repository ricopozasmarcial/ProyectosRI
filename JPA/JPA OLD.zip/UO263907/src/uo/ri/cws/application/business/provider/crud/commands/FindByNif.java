package uo.ri.cws.application.business.provider.crud.commands;

import java.sql.SQLException;
import java.util.Optional;

import uo.ri.cws.application.business.provider.ProviderDto;
import uo.ri.cws.application.business.util.DtoMapper;
import uo.ri.cws.application.business.util.command.Command;
import uo.ri.cws.application.persistence.PersistenceFactory;
import uo.ri.cws.application.persistence.provider.ProviderGateway;
import uo.ri.cws.application.persistence.provider.ProviderRecord;

public class FindByNif implements Command<Optional<ProviderDto>> {

	private String nif;
	private ProviderGateway pg;

	public FindByNif(String nif) {
		this.nif = nif;
		pg = PersistenceFactory.forProvider();
	}

	@Override
	public Optional<ProviderDto> execute() throws SQLException {
		if (nif.isEmpty() || nif == null) {
			throw new IllegalArgumentException("The provider nif cannot be null or lenght 0");
		}
		Optional<ProviderRecord> provider = pg.findByNif(nif);
		if (provider.isPresent())
			return DtoMapper.toProviderDto(provider);
		return Optional.empty();
	}

}
