package uo.ri.cws.application.business.invoice.create.commands;

public class PayOffInvoice {

}
