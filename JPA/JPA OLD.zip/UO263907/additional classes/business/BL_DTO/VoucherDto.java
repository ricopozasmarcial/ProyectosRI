package uo.ri.cws.application.business.invoice;

public class VoucherDto extends PaymentMeanDto {

	public String code;
	public String description;
	public Double available;

}
