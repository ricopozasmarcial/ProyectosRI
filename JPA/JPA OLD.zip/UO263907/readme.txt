
CarWorkshop_v0

 	- Mechanic menus is already done. Take a look. Notice connection, statement, ...
 		
 	- DDBB already contains data. 
 		
 	- Run database with the script in data folder
 		
 	- Run uo.ri.admin.MainMenu.java
 	  
 	- Complete the following use cases (cashier)
 		* List uncharged work by client
 		* Issue an invoice (Generar una factura para las avería que se indiquen) -- hecho
 		
 		* Bonus: Settle an invoice 
 		
 
