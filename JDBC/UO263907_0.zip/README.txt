UO263907

Marcial Rico Pozas

Ejercicio 0 (UO impar)

Debido a la versión de java empleada 9.0.4, los métodos .isEmtpy() 
de Optional tuvieron que ser sustituidos por .isPresent() con su 
correspondiente negación para mantener la lógica intacta.